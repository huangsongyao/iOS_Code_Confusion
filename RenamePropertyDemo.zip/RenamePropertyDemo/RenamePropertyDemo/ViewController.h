//
//  ViewController.h
//  RenamePropertyDemo
//
//  Created by huangsongyao on 2018/4/11.
//  Copyright © 2018年 huangsongyao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic, strong) NSString *hehehe;     //=> @property (nonatomic, strong) NSString *abc_hehehe;

- (void)test;                                       //=> - (void)abc_test;
- (void)test:(NSString *)t;                         //=> - (void)abc_test:(NSString *)t;
+ (void)test;                                       //=> + (void)abc_test;
+ (void)test:(NSString *)t;                         //=> + (void)abc_test:(NSString *)t;
- (NSString *)ttttl;

@end

