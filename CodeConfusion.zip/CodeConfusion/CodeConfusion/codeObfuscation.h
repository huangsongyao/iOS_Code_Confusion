#ifndef Demo_codeObfuscation_h
#define Demo_codeObfuscation_h
//confuse string at Wed Apr 11 18:41:41 CST 2018
#define randomStringWithLength U1OZcsedhsXOtSEFV57s
#define testViewContent JARDL6Zv3LMTl7v4I8oK

#endif
