#!/bin/sh

#  PlayScript.sh
#  RenamePropertyDemo
#
#  Created by huangsongyao on 2018/4/12.
#  Copyright © 2018年 huangsongyao. All rights reserved.

echo -e "\e[1;42m Green Background \e[0m"
