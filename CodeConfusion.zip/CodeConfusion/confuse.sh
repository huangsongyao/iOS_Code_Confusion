#!/usr/bin/env bash

ramdomString() {
    index=0
    str=""
    for i in {a..z}; do arr[index]=$i; index=`expr ${index} + 1`; done
    for i in {A..Z}; do arr[index]=$i; index=`expr ${index} + 1`; done
    for i in {0..9}; do arr[index]=$i; index=`expr ${index} + 1`; done
    for i in {1..20}; do str="$str${arr[$RANDOM%$index]}"; done
    echo $str
}

STRING_SYMBOL_FILE="$PROJECT_DIR/CodeConfusion/func.list"

CONFUSE_FILE="$PROJECT_DIR/CodeConfusion"

HEAD_FILE="$PROJECT_DIR/CodeConfusion/codeObfuscation.h"

export LC_CTYPE=C

#取以.h结尾的文件以+号或-号开头的行 | 去掉所有+号或－号 | 用空格代替符号 | n个空格跟着<号 替换成 <号 | 开头不能是IBAction | 用空格split字串取第二部分 | 排序 | 去重复 | 删除空行 | 删掉以init开头的行 >写进func.list
grep -h -r -I  "^[-+]" $CONFUSE_FILE  --include '*.[h]' |sed "s/[+-]//g"|sed "s/[();,: *\^\/\{]/ /g"|sed "s/[ ]*</</"| sed "/^[ ]*IBAction/d"|awk '{split($0,b," "); print b[2]; }'| sort|uniq |sed "/^$/d" >$STRING_SYMBOL_FILE

#取以.m或.h结尾的文件以+号或-号开头的行 | 去掉所有+号或－号 | 用空格代替符号| n个空格跟着<号 替换成 <号 | 开头不能是IBAction | 用空格split字串取第二部分 | 排序 | 去重复 | 删除空行 | 删掉以init开头的行 | 将工程中所有"rac_"开头的>写进func.list
#grep -h -r -I  "^[-+]" $CONFUSE_FILE  --include '*.[mh]' |sed "s/[+-]//g"|sed "s/[();,: *\^\/\{]/ /g"|sed "s/[ ]*</</"| sed "/^[ ]*IBAction/d"|awk '{split($0,b," "); print b[2]; }'| sort|uniq |sed "/^$/d"|sed -n "/^rac_/p" >$STRING_SYMBOL_FILE

rm -f $HEAD_FILE

touch $HEAD_FILE
echo '#ifndef Demo_codeObfuscation_h
#define Demo_codeObfuscation_h' >> $HEAD_FILE
echo "//confuse string at `date`" >> $HEAD_FILE
cat "$STRING_SYMBOL_FILE" | while read -ra line; do
if [[ ! -z "$line" ]]; then
ramdom=`ramdomString`
echo $line $ramdom
insertValue $line $ramdom
echo "#define $line $ramdom" >> $HEAD_FILE
fi
done
echo "#endif" >> $HEAD_FILE



