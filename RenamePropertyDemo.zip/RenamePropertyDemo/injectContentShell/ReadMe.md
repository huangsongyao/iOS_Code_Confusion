ReadMe.md

## 文件及其作用

### 文件夹处理相关文件
- RenameDir.sh 修改文件夹脚本

### 类处理相关文件
- GenRenameClasses.sh 从指定的目录读取类文件生成重命名类的配置文件RenameClasses.cfg
- RenameClasses.cfg 生成的重命名类的配置文件
- RenameClasses.sh 读取RenameClasses.cfg配置文件，修改配置的类名、修改引用、修改在pbxproj文件中的索引

### 属性处理相关文件

### 方法处理相关文件

### 注入内容处理相关文件
- injectedContentConfig.cfg 注入内容配置文件
- injectedContentShell.sh 注入内容脚本


## 使用方法
