//
//  NSString+RandomString.m
//  CodeConfusion
//
//  Created by fungo on 2018/4/11.
//  Copyright © 2018年 huangsongyao. All rights reserved.
//

#import "NSString+RandomString.h"

@implementation NSString (RandomString)

+ (NSString *)randomStringWithLength:(NSInteger)length
{
    NSString *string = [[NSString alloc]init];
    for (NSInteger i = 0; i < length; i ++) {
        NSInteger number = arc4random() % 36;
        if (number < 10) {
            NSInteger figure = arc4random() % 10;
            NSString *tempString = [NSString stringWithFormat:@"%ld", figure];
            string = [string stringByAppendingString:tempString];
        } else {
            NSInteger figure = (arc4random() % 26) + 97;
            char character = figure;
            NSString *tempString = [NSString stringWithFormat:@"%c", character];
            string = [string stringByAppendingString:tempString];
        }
    }
    return string;
}

@end
