//
//  ViewController.h
//  CodeConfusion
//
//  Created by fungo on 2018/4/10.
//  Copyright © 2018年 huangsongyao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic, strong) NSString *titleName;

- (void)testViewContent;

@end

