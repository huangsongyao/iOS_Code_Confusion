//
//  AppDelegate.h
//  RenamePropertyDemo
//
//  Created by huangsongyao on 2018/4/11.
//  Copyright © 2018年 huangsongyao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

