#!/bin/sh

#  Script.sh
#  RenamePropertyDemo
#
#  Created by huangsongyao on 2018/4/11.
#  Copyright © 2018年 huangsongyao. All rights reserved.


function scandir() {
    local cur_dir parent_dir workdir
    
    workdir=$0
    if [ ${workdir} = "/" ]
    then
        cur_dir=""
    else
        cur_dir=$(pwd)
    fi

#从当前脚本文件的目录进行递归遍历
    for dirlist in $(ls ${cur_dir})
        do
        if test -d ${dirlist};
        then
            cd ${dirlist}
            scandir ${cur_dir}/${dirlist}
            cd ..
        else
#“##”表示从左边算起的最后一个，“*”位于“.”的左侧表示删除“.”左侧的内容，最后返回“.”右侧的内容
#“-o”在shell中表示“或”，判断最后拿到的文件名称是否是以h或者m为结尾的文件，即oc的文件
            if [ ${dirlist##*.} == "h" -o ${dirlist##*.} == "m" ]
            then
#如果是以h或者m为结尾的oc文件，则打印文件的名称
                echo ${dirlist}
#打印.h或者.m文件的全部内容
#                cat ${dirlist} | awk '{print $0}'

#打印.h或者.m文件的每一行中不含空格符的内容
#                for line in $(cat ${dirlist})
#                do
#                    echo $line
#                done

#打印.h或者.m文件的每一行的内容
                cat ${dirlist}| while read line
                do
#                    echo $line
#如果每行从右边起的第一个“(”截取的字符串满足“- (”或者“+ (”或者“-(”或者“+(”,表示这是OC的方法  --hehehhe
                    if [ ${line%%(*} == "- (" ];then
                        object_c_method = ${line#*)} + ${line}
                        sed -i 's/${object_c_method}//g'
                        echo $line
                    fi
                done
#如果当前所遍历的文件不是以.h或者.m为后缀的文件，则打印出文件的绝对路径
            else
                echo ${cur_dir}/${dirlist}
            fi
        fi
    done
}

if test -d $1;then
    scandir $1
elif test -f $1;then
    echo "输入的是一个文件，而不是一个目录，请重新输入并重试。"
    exit 1
else
    echo "输入的目录不存在！"
    exit 1
fi



