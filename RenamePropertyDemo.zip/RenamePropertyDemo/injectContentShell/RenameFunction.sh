#!/bin/bash
# 方法重命名脚本


