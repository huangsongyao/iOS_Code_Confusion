//
//  main.m
//  RenamePropertyDemo
//
//  Created by huangsongyao on 2018/4/11.
//  Copyright © 2018年 huangsongyao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
