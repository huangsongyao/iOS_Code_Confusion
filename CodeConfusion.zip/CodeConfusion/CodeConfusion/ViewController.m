//
//  ViewController.m
//  CodeConfusion
//
//  Created by fungo on 2018/4/10.
//  Copyright © 2018年 huangsongyao. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.titleName = [self name];
    // Do any additional setup after loading the view, typically from a nib.
}

- (NSString *)name
{
    return @"888";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
